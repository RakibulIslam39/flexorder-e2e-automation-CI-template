import axios from "axios";
import * as FilePond from "filepond";
import FilePondPluginFileEncode from "filepond-plugin-file-encode";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";

export const Ajax = {
  async request(action, data, method = "POST") {
    const axiosObject = {
      url: osgsw_script.ajax_url + "?action=" + action,
      method,
      data,
      Headers: {
        "Content-Type": "x-www-form-urlencoded",
      },
    };

    if (method === "GET") {
      delete axiosObject.data;
      axiosObject.url += "&" + Ajax.serialize(data);
    }

    let response = await axios(axiosObject);

    return response.data;
  },

  async get(action, data = null) {
    return await this.request(action, data, "GET");
  },

  async post(action, data = null) {
    return await this.request(action, data, "POST");
  },

  serialize(data) {
    let serialized = "";

    for (let key in data) {
      serialized += key + "=" + data[key] + "&";
    }

    return serialized.slice(0, -1);
  },
};

import "./../lib/sizzle.min.js";

export const Toast = Sizzle.mixins({
  position: "top-right",
  ok: false,
  timeout: 2000,
  progress: true,
  icon: "success",
  backdrop:false,
  cancel: false,
  // margin top 
  classes: {
    modal: "mt-5",
  },
});
export const Vn = Sizzle.mixins({
  position: "top-right",
  ok: false,
  timeout: 2000,
  progress: true,
  icon: "success",
  backdrop: false,
  cancel: false,
  size: 'md',
  classes: {
    modal: "mt-5", // Modal styling
  },
});

/**
 * Logical compare
 */

export const isTrue = (value) => {
  return value === true || value === "true" || value === 1 || value === "1";
};

export const isEqual = () => {
  let args = Array.from(arguments);
  let first = args.shift();
  return args.every(function (value) {
    return first === value;
  });
};

export const FilePondHandler = () => {
  FilePond.registerPlugin(
    // encodes the file as base64 data
    FilePondPluginFileEncode,

    // previews dropped images
    FilePondPluginImagePreview
  );

  FilePond.setOptions({
    dropOnPage: true,
    dropOnElement: true,
  });

  return FilePond;
};

export const mockServer = {
  remove: null,
  revert: null,
  process: function (
    fieldName,
    file,
    metadata,
    load,
    error,
    progress,
    abort,
    transfer,
    options
  ) {
    var prog = 0;
    var total = file.size;
    var speed = 128 * 1024; // KB/s
    var aborted = false;

    const tick = function () {
      if (aborted) return;

      prog += Math.random() * speed;
      prog = Math.min(total, prog);

      progress(true, prog, total);

      if (prog === total) {
        load(Date.now());
        return;
      }

      setTimeout(tick, Math.random() * 50);
    };

    tick();

    return {
      abort: function () {
        aborted = true;

        abort();
      },
    };
  },
};

// log
export const Log = function () {
   
  if (typeof(osgsw_script) === 'undefined' || osgsw_script.is_debug != 1) return;

  let args = Array.from(arguments);
  console.log(
      "%cOSGSW",
      "background: #005ae0; color: white; font-size: 9px; padding: 2px 4px; border-radius: 2px;",
      ...args
  );

}; 