import Buttons from "./buttons";

(function () {
  const Events = {

    get isPro(){
      return osgsw_script.is_ultimate_license_activated
    },

    init() {
      new Buttons();
      Events.bindEvents();  
    },

    bindEvents: () => {
      const promo_buttons = document.querySelectorAll(".osgsw-promo");
      if (promo_buttons && promo_buttons.length) {
        promo_buttons.forEach((button) => {
          button.addEventListener("click", Events.displayPromo);
        });
      }

      const sync_buttons = document.querySelectorAll(".sync-button");
      if (sync_buttons && sync_buttons.length) {
        sync_buttons.forEach((button) => {
          button.addEventListener("click", Events.syncOnGoogleSheet);
        });
      } 
    },

    displayPromo(e) {
 
      if (Events.isPro) {
        return;
      }

      e.preventDefault();
      WPPOOL.Popup('order_sync_with_google_sheets_for_woocommerce').show();
    }, 
 
  };

  document.addEventListener("DOMContentLoaded", Events.init);
})();
