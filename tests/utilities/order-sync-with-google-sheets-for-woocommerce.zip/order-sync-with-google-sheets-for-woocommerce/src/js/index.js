import Alpine from "alpinejs";
global.Alpine = Alpine;
import '@babel/polyfill';
import  "./events";

import Dashboard from "./dashboard";
import Setup from "./setup";


Alpine.data("dashboard", Dashboard);
Alpine.data("setup", Setup);

Alpine.start();

 