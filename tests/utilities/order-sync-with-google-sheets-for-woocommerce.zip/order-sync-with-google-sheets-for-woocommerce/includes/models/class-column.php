<?php
/**
 * Class Column
 * includes/model/Column.php
 *
 * @package OrderSyncWithGoogleSheetForWooCommerce
 */

namespace OrderSyncWithGoogleSheetForWooCommerce;

defined( 'ABSPATH' ) || die( 'No script kiddies please!' );

if ( ! class_exists( '\OrderSyncWithGoogleSheetForWooCommerce\Column' ) ) {
	/**
	 * Column class
	 */
	class Column extends Base {
		/**
		 * Column properties
		 */
		public function get_all_columns() {
			$columns = [
				'order_id' => [
					'label' => __( 'Order ID', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'  => 'term',
				],
				'product_names' => [
					'label' => __( 'Product Names', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'  => 'meta',
				],
				'order_status' => [
					'label' => __( 'Order Status', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'  => 'meta',
				],
				'total_items' => [
					'label' => __( 'Total Items', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'  => 'meta',
				],
				'product_sku_sync' => [
					'label' => __( 'Product SKU', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'  => 'term',
				],
				'order_totals' => [
					'label'    => __( 'Total Price', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				
				'show_billing_details' => [
					'label'    => __( 'Billing Details', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'shipping_details' => [
					'label'    => __( 'Shipping Details', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],

				// Billing Seperation 
				'show_billing_first_name' => [
					'label'    => __( 'Billing First Name', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_last_name' => [
					'label'    => __( 'Billing Last Name', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_address_1' => [
					'label'    => __( 'Billing Address 1', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_city' => [
					'label'    => __( 'Billing City', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_postcode' => [
					'label'    => __( 'Billing Postcode', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_country' => [
					'label'    => __( 'Billing Country', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_address_2' => [
					'label'    => __( 'Billing Address 2', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_company' => [
					'label'    => __( 'Billing Company', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_state' => [
					'label'    => __( 'Billing State', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_email' => [
					'label'    => __( 'Billing Email', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_billing_phone' => [
					'label'    => __( 'Billing Phone', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],

				// Shipping Seperation 
				'show_shipping_first_name' => [
					'label'    => __( 'Shipping First Name', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_last_name' => [
					'label'    => __( 'Shipping Last Name', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_address_1' => [
					'label'    => __( 'Shipping Address 1', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_city' => [
					'label'    => __( 'Shipping City', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_postcode' => [
					'label'    => __( 'Shipping Postcode', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_country' => [
					'label'    => __( 'Shipping Country', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_address_2' => [
					'label'    => __( 'Shipping Address 2', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_company' => [
					'label'    => __( 'Shipping Company', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_state' => [
					'label'    => __( 'Shipping State', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_email' => [
					'label'    => __( 'Shipping Email', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'show_shipping_phone' => [
					'label'    => __( 'Shipping Phone', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],

				// End Seperation
				'total_discount' => [
					'label'    => __( 'Total Discount', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],

				'order_date' => [
					'label'    => __( 'Order Date', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'payment_method' => [
					'label'    => __( 'Payment Method', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'customer_note' => [
					'label'    => __( 'Customer Note', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'who_place_order' => [
					'label'    => __( 'Order Placed by', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'order_url' => [
					'label'    => __( 'Order URL', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'     => 'meta',
				],
				'order_note' => [
					'label' => __( 'Order Note', 'order-sync-with-google-sheets-for-woocommerce' ),
					'type'  => 'term',
				],
				
			];
			$columns = apply_filters( 'osgsw_add_row_before_custom_fields', $columns );
			$custom_meta_value = $this->osgsw_custom_meta_fields();
			if ( ! empty( $custom_meta_value ) ) {
				$columns = $columns + $custom_meta_value;
			}
			return apply_filters( 'osgsw_columns', $columns );
		}
		
		/**
		 * Get Editable Columns
		 */
		public function get_columns() {
			$columns          = $this->get_all_columns();
			$total_discount   = true === wp_validate_boolean( osgsw_get_option( 'total_discount', false ) );
			$order_date       = true === wp_validate_boolean( osgsw_get_option( 'show_order_date', false ) );
			$payment_method   = true === wp_validate_boolean( osgsw_get_option( 'show_payment_method', false ) );
			$customer_note    = true === wp_validate_boolean( osgsw_get_option( 'show_customer_note', false ) );
			$order_url        = true === wp_validate_boolean( osgsw_get_option( 'show_order_url', false ) );
			$who_place_order  = true === wp_validate_boolean( osgsw_get_option( 'who_place_order', false ) );
			$total_items      = true === wp_validate_boolean( osgsw_get_option( 'sync_total_items', false ) );
			$sync_total_price = true === wp_validate_boolean( osgsw_get_option( 'sync_total_price', false ) );
			
			$shipping_details = true === wp_validate_boolean( osgsw_get_option( 'add_shipping_details_sheet', false ) );
			$billing_details  = true === wp_validate_boolean( osgsw_get_option( 'show_billing_details', false ) );
			$make_billing_shipping_seperate = true === wp_validate_boolean( osgsw_get_option( 'make_billing_shipping_seperate', false ) );

			$show_order_note  = true === wp_validate_boolean( osgsw_get_option( 'show_order_note', false ) );
			$custom_meta_fields = true === wp_validate_boolean( osgsw_get_option( 'show_custom_meta_fields', false ) );
			$product_sku_sync = wp_validate_boolean( get_option( OSGSW_PREFIX . 'product_sku_sync', false ) );

			$sync_order_products = wp_validate_boolean( get_option( OSGSW_PREFIX . 'sync_order_products', true ) );
			$sync_order_status = wp_validate_boolean( get_option( OSGSW_PREFIX . 'sync_order_status', true ) );
		
			// Individual billing field settings
			$show_billing_first_name = true === wp_validate_boolean( osgsw_get_option( 'show_billing_first_name', false ) );
			$show_billing_last_name = true === wp_validate_boolean( osgsw_get_option( 'show_billing_last_name', false ) );
			$show_billing_address_1 = true === wp_validate_boolean( osgsw_get_option( 'show_billing_address_1', false ) );
			$show_billing_address_2 = true === wp_validate_boolean( osgsw_get_option( 'show_billing_address_2', false ) );
			$show_billing_city = true === wp_validate_boolean( osgsw_get_option( 'show_billing_city', false ) );
			$show_billing_state = true === wp_validate_boolean( osgsw_get_option( 'show_billing_state', false ) );
			$show_billing_postcode = true === wp_validate_boolean( osgsw_get_option( 'show_billing_postcode', false ) );
			$show_billing_country = true === wp_validate_boolean( osgsw_get_option( 'show_billing_country', false ) );
			$show_billing_email = true === wp_validate_boolean( osgsw_get_option( 'show_billing_email', false ) );
			$show_billing_phone = true === wp_validate_boolean( osgsw_get_option( 'show_billing_phone', false ) );
			$show_billing_company = true === wp_validate_boolean( osgsw_get_option( 'show_billing_company', false ) );
		
			// Individual shipping field settings
			$show_shipping_first_name = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_first_name', false ) );
			$show_shipping_last_name = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_last_name', false ) );
			$show_shipping_address_1 = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_address_1', false ) );
			$show_shipping_address_2 = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_address_2', false ) );
			$show_shipping_city = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_city', false ) );
			$show_shipping_state = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_state', false ) );
			$show_shipping_postcode = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_postcode', false ) );
			$show_shipping_country = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_country', false ) );
			$show_shipping_email = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_email', false ) );
			$show_shipping_phone = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_phone', false ) );
			$show_shipping_company = true === wp_validate_boolean( osgsw_get_option( 'show_shipping_company', false ) );


			// Handle separate billing and shipping columns.
			if ($make_billing_shipping_seperate) {
				// Unset the combined columns.
				unset($columns['show_billing_details']);
				unset($columns['shipping_details']);
		
				// Handle individual billing fields.
				if (!$billing_details || !$show_billing_first_name) unset($columns['show_billing_first_name']);
				if (!$billing_details || !$show_billing_last_name) unset($columns['show_billing_last_name']);
				if (!$billing_details || !$show_billing_address_1) unset($columns['show_billing_address_1']);
				if (!$billing_details || !$show_billing_address_2) unset($columns['show_billing_address_2']);
				if (!$billing_details || !$show_billing_city) unset($columns['show_billing_city']);
				if (!$billing_details || !$show_billing_state) unset($columns['show_billing_state']);
				if (!$billing_details || !$show_billing_postcode) unset($columns['show_billing_postcode']);
				if (!$billing_details || !$show_billing_country) unset($columns['show_billing_country']);
				if (!$billing_details || !$show_billing_email) unset($columns['show_billing_email']);
				if (!$billing_details || !$show_billing_phone) unset($columns['show_billing_phone']);
				if (!$billing_details || !$show_billing_company) unset($columns['show_billing_company']);
		
				// Handle individual shipping fields.
				if (!$shipping_details || !$show_shipping_first_name) unset($columns['show_shipping_first_name']);
				if (!$shipping_details || !$show_shipping_last_name) unset($columns['show_shipping_last_name']);
				if (!$shipping_details || !$show_shipping_address_1) unset($columns['show_shipping_address_1']);
				if (!$shipping_details || !$show_shipping_address_2) unset($columns['show_shipping_address_2']);
				if (!$shipping_details || !$show_shipping_city) unset($columns['show_shipping_city']);
				if (!$shipping_details || !$show_shipping_state) unset($columns['show_shipping_state']);
				if (!$shipping_details || !$show_shipping_postcode) unset($columns['show_shipping_postcode']);
				if (!$shipping_details || !$show_shipping_country) unset($columns['show_shipping_country']);
				if (!$shipping_details || !$show_shipping_email) unset($columns['show_shipping_email']);
				if (!$shipping_details || !$show_shipping_phone) unset($columns['show_shipping_phone']);
				if (!$shipping_details || !$show_shipping_company) unset($columns['show_shipping_company']);
			} else {
				// Unset all individual billing and shipping columns.
				$billing_keys = [
					'show_billing_first_name', 'show_billing_last_name', 'show_billing_address_1',
					'show_billing_city', 'show_billing_postcode', 'show_billing_country',
					'show_billing_address_2', 'show_billing_company', 'show_billing_state',
					'show_billing_email', 'show_billing_phone'
				];
				foreach ($billing_keys as $key) {
					unset($columns[$key]);
				}
		
				// Unset all individual shipping columns.
				$shipping_keys = [
					'show_shipping_first_name', 'show_shipping_last_name', 'show_shipping_address_1',
					'show_shipping_city', 'show_shipping_postcode', 'show_shipping_country',
					'show_shipping_address_2', 'show_shipping_company', 'show_shipping_state',
					'show_shipping_email', 'show_shipping_phone'
				];
				foreach ($shipping_keys as $key) {
					unset($columns[$key]);
				}
		
				// Handle the combined columns based on their respective settings.
				if (!$billing_details) {
					unset($columns['show_billing_details']);
				}
				if (!$shipping_details) {
					unset($columns['shipping_details']);
				}
			}
		
			
			if (!$sync_order_products) {
				unset($columns['product_names']);
			}
			if (!$sync_order_status) {
				unset($columns['order_status']);
			}


			if (!$total_items) {
				unset($columns['total_items']);
			}
			if (!$product_sku_sync) {
				unset($columns['product_sku_sync']);
			}
			if (!$sync_total_price) {
				unset($columns['order_totals']);
			}
			if (!$total_discount) {
				unset($columns['total_discount']);
			}
			if (!$order_date) {
				unset($columns['order_date']);
			}
			if (!$payment_method) {
				unset($columns['payment_method']);
			}
			if (!$order_url) {
				unset($columns['order_url']);
			}
			if (!$customer_note) {
				unset($columns['customer_note']);
			}
			if (!$who_place_order) {
				unset($columns['who_place_order']);
			}
			if (!$show_order_note) {
				unset($columns['order_note']);
			}
			if (!$custom_meta_fields) {
				unset($columns['show_custom_meta_fields']);
			}
		
			$columns = apply_filters('osgsw_unset_columns', $columns);
		
			return $columns;
		}

		/**
		 * Get Editable Column Keys
		 */
		public function get_column_keys() {
			$columns = array_filter(
				$this->get_columns(),
				function ( $column ) {
					return isset( $column['column'] ) ? $column['column'] : true;
				}
			);

			$keys = array_keys( $columns );

			return $keys;
		}

		/**
		 * Get Editable Column Values
		 */
		public function get_column_names() {
			$columns = array_filter(
				$this->get_columns(),
				function ( $column ) {
					return isset( $column['column'] ) ? $column['column'] : true;
				}
			);
			$values = array_column( array_values( $columns ), 'label' );

			return $values;
		}

		/**
		 * Get column keys for query
		 */
		public function get_queryable_columns() {
			$columns = $this->get_columns();
			$columns = array_filter(
				$columns,
				function ( $column ) {
					return isset( $column['query'] ) ? $column['query'] : true;
				}
			);

			return $columns;
		}

		/**
		 * Get column keys for query
		 */
		public function get_queryable_column_keys() {
			$columns = $this->get_queryable_columns();
			$keys = array_keys( $columns );
			return $keys;
		}

		/**
		 * Format custom meta value for OSGS
		 *
		 * @return array
		 */
		public function osgsw_custom_meta_fields() {
			$checked_value    = osgsw_get_option( 'show_custom_fields' );
			$on_custom_fields = osgsw_get_option( 'show_custom_meta_fields' );
			$on_custom_fields = true === wp_validate_boolean( osgsw_get_option( 'show_custom_meta_fields', false ) );
			$custom_array = [];
			if ( $on_custom_fields ) {
				$priority = 1000;
				if ( is_array( $checked_value ) && ! empty( $checked_value ) ) {
					foreach ( $checked_value as $key => $value ) {
						$check_type = check_osgsw_file_type( $value );
						if ( 'suported' === $check_type ) {
							$custom_array[ $value ]['label']     = $value;
							$custom_array[ $value ]['type']      = 'meta';
							$custom_array[ $value ]['priority']  = $priority++;
						}
					}
				}
			}
				return $custom_array;
		}
	}
}
